@echo off
setlocal
cd /d "%~dp0"

echo ==========================================
echo Building "mission find Jeb.darws.things"
echo ==========================================

where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher "py" was not found.
  echo Install Python 3.11 or newer from python.org and try again.
  pause
  exit /b 1
)

py -m pip install --upgrade pip
if errorlevel 1 goto :fail

py -m pip install -r requirements.txt
if errorlevel 1 goto :fail

py -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --onefile ^
  --windowed ^
  --name "mission find Jeb.darws.things" ^
  app.py

if errorlevel 1 goto :fail

echo.
echo Build finished.
echo Your EXE is in:
echo %CD%\dist\mission find Jeb.darws.things.exe
echo.
pause
exit /b 0

:fail
echo.
echo Build failed. Read the error messages above.
pause
exit /b 1
