@echo off
setlocal
cd /d "%~dp0"

py -m pip install -r requirements.txt
if errorlevel 1 (
  echo Could not install Python packages.
  pause
  exit /b 1
)

py app.py
