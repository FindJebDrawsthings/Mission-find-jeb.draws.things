# mission find Jeb.darws.things v3 — stricter number detection

This version is designed to reduce the random-frame / false-positive problem.

## Changes
- **Strict detection is ON by default**
- raises the effective OCR confidence floor to 62 in strict mode
- rejects tiny and near-empty OCR boxes
- adds padding around candidate number regions
- enlarges each crop 3× before OCR
- reads each candidate using:
  - normal grayscale
  - Otsu threshold
  - adaptive threshold
- in strict mode, a detected number must be recognized the same way by at least **2 of the 3 OCR passes**
- still shows a thumbnail picture and larger preview for each accepted number

## If it misses real numbers
Try these in order:
1. Lower "Minimum OCR confidence" from 45 to 35.
2. Turn OFF "Strict detection".
3. Keep strict mode on but use a higher-resolution copy of the video.

## If it still finds junk
Raise "Minimum OCR confidence" to 65-75.

## Run
Double-click `run_app.bat`

## Build EXE
Double-click `build_windows_exe.bat`
